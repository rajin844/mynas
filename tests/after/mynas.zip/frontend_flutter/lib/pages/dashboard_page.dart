import 'package:flutter/material.dart';
import '../services/ws_service.dart';

class DashboardPage extends StatefulWidget {
  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> {
  String last = 'waiting...';
  final ws = WebSocketService();

  @override
  void initState() {
    super.initState();
    ws.stream.listen((msg) {
      setState(() => last = msg.toString());
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('MyNAS v7 Dashboard')),
      body: Center(child: Text(last)),
    );
  }
}
