from realtime.websocket_server import WSManagerProxy

def create_share(name, path, protocol='smb'):
    WSManagerProxy.broadcast({'module':'shares','action':'create','name':name,'path':path,'protocol':protocol})
    return True

def delete_share(name):
    WSManagerProxy.broadcast({'module':'shares','action':'delete','name':name})
    return True
