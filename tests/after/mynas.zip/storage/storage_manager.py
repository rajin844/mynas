from backend.config_manager import ConfigManager
from realtime.websocket_server import WSManagerProxy
cfg = ConfigManager()

def create_pool(name, devices):
    pool = {'name': name, 'devices': devices}
    cfg.add_pool(pool)
    WSManagerProxy.broadcast({'module':'storage','action':'create_pool','name':name})
    return pool

def delete_pool(name):
    cfg.delete_pool(name)
    WSManagerProxy.broadcast({'module':'storage','action':'delete_pool','name':name})
    return True
