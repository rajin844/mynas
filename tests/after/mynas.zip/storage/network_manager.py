from realtime.websocket_server import WSManagerProxy

def update_interface(name, ip):
    WSManagerProxy.broadcast({'module':'network','action':'update','interface':name,'ip':ip})
    return True
