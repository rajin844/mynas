from realtime.websocket_server import WSManagerProxy

def create_pool(name, devices):
    # placeholder: simulate creation
    WSManagerProxy.broadcast({'module':'zfs','action':'create_pool','name':name})
    return True

def create_dataset(pool, name):
    WSManagerProxy.broadcast({'module':'zfs','action':'create_dataset','dataset': f"{pool}/{name}"})
    return True
