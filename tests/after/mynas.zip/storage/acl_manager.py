from backend.permissions import apply_posix_acl, remove_posix_acl

def set_acl(path, username, permissions):
    return apply_posix_acl(path, username, permissions)

def remove_acl(path, username):
    return remove_posix_acl(path, username)
