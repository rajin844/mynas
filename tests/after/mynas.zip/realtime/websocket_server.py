from typing import List, Dict, Any
from fastapi import WebSocket
import asyncio

class WSManager:
    def __init__(self):
        self.active_connections: List[WebSocket] = []
        self.lock = asyncio.Lock()

    async def connect(self, websocket: WebSocket):
        await websocket.accept()
        async with self.lock:
            self.active_connections.append(websocket)

    def disconnect(self, websocket: WebSocket):
        try:
            self.active_connections.remove(websocket)
        except Exception:
            pass

    def client_count(self):
        return len(self.active_connections)

    async def broadcast(self, message: Dict[str, Any]):
        remove_list = []
        for ws in list(self.active_connections):
            try:
                await ws.send_json(message)
            except Exception:
                remove_list.append(ws)
        for ws in remove_list:
            self.disconnect(ws)

class WSManagerProxy:
    _ws_manager: WSManager = None

    @classmethod
    def register(cls, ws_manager: WSManager):
        cls._ws_manager = ws_manager

    @classmethod
    def broadcast(cls, msg: Dict[str, Any]):
        if cls._ws_manager:
            try:
                import asyncio
                asyncio.create_task(cls._ws_manager.broadcast(msg))
            except Exception:
                pass
