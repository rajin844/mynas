import psutil, asyncio
from typing import Dict
from realtime.websocket_server import WSManagerProxy

def get_cpu_percent(interval: float = 0.1) -> float:
    return psutil.cpu_percent(interval=interval)

def get_memory_percent() -> float:
    return psutil.virtual_memory().percent

def get_disk_percent(path: str = '/') -> float:
    return psutil.disk_usage(path).percent

async def periodic_broadcast(interval: float = 5.0):
    while True:
        try:
            data: Dict = {
                'module': 'monitoring',
                'cpu': int(get_cpu_percent(0.1)),
                'memory': int(get_memory_percent()),
                'disk': int(get_disk_percent('/')),
            }
            try:
                WSManagerProxy.broadcast(data)
            except Exception:
                pass
        except Exception:
            pass
        await asyncio.sleep(interval)
