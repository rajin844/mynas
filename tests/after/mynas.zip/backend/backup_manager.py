import shutil, subprocess
from pathlib import Path
from typing import List, Optional
from backend.config_manager import ConfigManager

ROOT = Path(__file__).resolve().parent.parent
CONFIG_DIR = ROOT / 'config'
BACKUP_DIR = CONFIG_DIR / 'backups'
cfg = ConfigManager()

def list_backups() -> List[str]:
    BACKUP_DIR.mkdir(parents=True, exist_ok=True)
    files = sorted(BACKUP_DIR.glob('config_*.json'), reverse=True)
    return [f.name for f in files]

def create_config_backup() -> Optional[str]:
    if not (CONFIG_DIR / 'config.json').exists():
        return None
    cfg.save(cfg.load())
    files = list_backups()
    return files[0] if files else None

def restore_config_backup(filename: str) -> bool:
    src = BACKUP_DIR / filename
    dst = CONFIG_DIR / 'config.json'
    if not src.exists():
        return False
    shutil.copy(src, dst)
    _try_broadcast({'module': 'backup', 'action': 'restore', 'file': filename})
    return True

def run_rsync_backup(source: str, destination: str) -> bool:
    try:
        subprocess.check_call(['rsync', '-a', source, destination])
        _try_broadcast({'module': 'backup', 'action': 'rsync', 'source': source, 'destination': destination})
        return True
    except Exception:
        return False

def _try_broadcast(msg: dict):
    try:
        from realtime.websocket_server import WSManagerProxy
        WSManagerProxy.broadcast(msg)
    except Exception:
        pass
