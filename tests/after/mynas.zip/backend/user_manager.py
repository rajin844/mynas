import hashlib, secrets
from typing import Optional
from backend.config_manager import ConfigManager

cfg = ConfigManager()

def _hash_password(password: str, salt: Optional[str] = None) -> dict:
    if salt is None:
        salt = secrets.token_hex(16)
    h = hashlib.sha256((salt + password).encode('utf-8')).hexdigest()
    return {'salt': salt, 'hash': h}

def list_users() -> list:
    cfg_data = cfg.load()
    return cfg_data.get('users', [])

def get_user(username: str) -> Optional[dict]:
    users = list_users()
    for u in users:
        if u.get('username') == username:
            return u
    return None

def add_user(username: str, password: str, role: str = 'user') -> dict:
    if get_user(username):
        raise ValueError('User already exists')
    pwd = _hash_password(password)
    user_obj = {'username': username, 'password': pwd, 'role': role}
    cfg_data = cfg.load()
    users = cfg_data.setdefault('users', [])
    users.append(user_obj)
    cfg.save(cfg_data)
    _try_broadcast({'module': 'user', 'action': 'create', 'user': username})
    return user_obj

def delete_user(username: str) -> bool:
    cfg_data = cfg.load()
    users = cfg_data.get('users', [])
    new_users = [u for u in users if u.get('username') != username]
    if len(new_users) == len(users):
        return False
    cfg_data['users'] = new_users
    cfg.save(cfg_data)
    _try_broadcast({'module': 'user', 'action': 'delete', 'user': username})
    return True

def verify_password(username: str, password: str) -> bool:
    user = get_user(username)
    if not user:
        return False
    stored = user.get('password', {})
    salt = stored.get('salt')
    expected = stored.get('hash')
    if not salt or not expected:
        return False
    return _hash_password(password, salt)['hash'] == expected

def _try_broadcast(message: dict):
    try:
        from realtime.websocket_server import WSManagerProxy
        WSManagerProxy.broadcast(message)
    except Exception:
        pass
