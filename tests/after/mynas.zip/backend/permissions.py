import subprocess
from typing import List
from backend.config_manager import ConfigManager

cfg = ConfigManager()

def role_check(username: str, allowed_roles: List[str]) -> bool:
    users = cfg.load().get('users', [])
    for u in users:
        if u.get('username') == username and u.get('role') in allowed_roles:
            return True
    return False

def apply_posix_acl(path: str, username: str, permissions: str) -> bool:
    try:
        subprocess.check_call(['setfacl', '-m', f'u:{username}:{permissions}', path])
        _try_broadcast({'module': 'acl', 'action': 'apply', 'path': path, 'user': username, 'permissions': permissions})
        return True
    except Exception:
        return False

def remove_posix_acl(path: str, username: str) -> bool:
    try:
        subprocess.check_call(['setfacl', '-x', f'u:{username}', path])
        _try_broadcast({'module': 'acl', 'action': 'remove', 'path': path, 'user': username})
        return True
    except Exception:
        return False

def _try_broadcast(message: dict):
    try:
        from realtime.websocket_server import WSManagerProxy
        WSManagerProxy.broadcast(message)
    except Exception:
        pass
