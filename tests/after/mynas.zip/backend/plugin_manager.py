import importlib, os, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
PLUGINS_DIR = ROOT / 'plugins'

def discover_plugins() -> list:
    if not PLUGINS_DIR.exists(): return []
    return [f[:-3] for f in os.listdir(PLUGINS_DIR) if f.endswith('.py') and f != '__init__.py']

def load_plugin(name: str):
    module_path = f'backend.plugins.{name}'
    try:
        sys.path.insert(0, str(ROOT))
        mod = importlib.import_module(module_path)
        meta = getattr(mod, 'metadata', None)
        if hasattr(mod, 'register'):
            try:
                mod.register()
            except TypeError:
                pass
        return {'name': name, 'metadata': meta}
    except Exception as e:
        return {'name': name, 'error': str(e)}

def load_all():
    return [load_plugin(p) for p in discover_plugins()]
